$Global:rm = Read-Host "Path"
Remove-Item $rm -Force  -Recurse -ErrorAction SilentlyContinue