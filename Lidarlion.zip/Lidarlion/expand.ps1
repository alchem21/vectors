$Global:dest = Read-Host "Path"

if (Test-Path $dest) {
# $path exists
if (((Get-Item $dest).PSIsContainer) -and
((Get-Item $dest).PSDrive.Provider.Name -eq "FileSystem")) {
# $path is a container and provider is "FileSystem"
Write-Output "File moved to $dest"
} else {
Write-Output "Connot move to $dest since it is not a vailid path"
}
}


Expand-Archive -F:\scoop\apps\lidar_fetch\1.1.0\Lidarlion\Lidarlion.zip -DestinationPath $dest
