$Global:dest = Read-Host "Path"
Expand-Archive F:\scoop\apps\lidarlion\1.1.0\Lidarlion\Lidarlion.zip  -DestinationPath $dest
