$Global:dest = Read-Host "Path(Use '\\' instead of '\'):"
Expand-Archive F:\scoop\apps\lidarlion\1.1.0\Lidarlion\Lidarlion.zip  -DestinationPath $dest
Add-Content -Path F:\scoop\apps\lidarlion\1.1.0\Lidarlion\path.txt "route=$dest\\Lidarlion"

