$Path = "F:\scoop\apps\lidarlion\1.1.0\Lidarlionv1.1.0\path.txt"
$values = Get-Content $Path | Out-String | ConvertFrom-StringData
$values.route
Remove-Item $values.route -Force  -Recurse -ErrorAction SilentlyContinue