$Global:dest = Read-Host "Path(Use '\\' instead of '\'):"
Expand-Archive F:\scoop\apps\lidarlion\1.1.0\Lidarlionv1.1.0\Lidarlionv1.1.0.zip  -DestinationPath $dest
Add-Content -Path F:\scoop\apps\lidarlion\1.1.0\Lidarlionv1.1.0\path.txt "route=$dest"

